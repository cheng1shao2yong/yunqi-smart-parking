<?php
declare(strict_types=1);
namespace addons\plugin\area;

class Install{

    public static $files=[
        'app/common/model/Area.php'
    ];

    public static $unpack=[

    ];

    public static $menu=[

    ];

    public static $require=[

    ];

    public static $config=[

    ];

    //安装扩展时的回调方法
    public static function install()
    {

    }

    //卸载扩展时的回调方法
    public static function uninstall()
    {

    }

}